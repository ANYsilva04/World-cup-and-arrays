﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_e_objetos
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
