﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira 5 números, para que o pograma faça a soma deles todos");
            Console.WriteLine("1 Número:");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("2 Número:");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("3 Número:");
            int c = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("4 Número:");
            int d = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("5 Número:");
            int e = Convert.ToInt32(Console.ReadLine());

            int[] numeros2 = { a, b, c, d, e };
            int[] numeros = new int[5];
            Console.WriteLine(numeros2[1]);
            numeros[0] = a;
            numeros[1] = b;
            numeros[2] = c;
            numeros[3] = d;
            numeros[4] = e;
            Console.WriteLine("A soma dos números todos é de:" (numeros[a] + numeros[b] + numeros[c] + numeros[d] + numeros[e]));
            Console.ReadLine();
        }
    }
}
