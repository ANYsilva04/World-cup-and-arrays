﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio_teste_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String[] arr = { "Even ", "Odd" };
            Console.Write("Enter the number: ");
            int no = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(arr[no % 2]);
            Console.ReadLine();
        }
    }
}
