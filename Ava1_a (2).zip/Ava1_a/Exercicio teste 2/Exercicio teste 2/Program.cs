﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio_teste_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
        begin:
            i = i + 1;
            Console.Write(" " + i + " ");
            if (i < 50)
            {
                goto begin;
            }
            Console.ReadLine();
        }
    }
}
