﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("loop 1 a 50");
            int i = 1;
           
            for (i = 1; i < 50; (i++))
            {
                Console.WriteLine(i);
            }

            Console.ReadLine();
        }
    }
}
