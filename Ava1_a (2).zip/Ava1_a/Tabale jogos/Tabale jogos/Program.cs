﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tabale_jogos
{
    internal class Program
    {
        class MainClass
        {







            //<-----------------------------COMEÇO DA ESTRUTURA CLASSIFICAÇÃO---------------------------------------------->

            public struct classificacao
            {
                public int Posicao;//Aqui declara-se a posição da equipa
                public string NomeEquipa;//Aqui declara-se o nome da equipa
                public int Pts;//Aqui declara-se os pontos da equipa
                public int V;//Aqui declara-se as vitorias da equipa	
                public int J;//Aqui declara-se os jogos da equipa
                public int E;//Aqui declara-se os empates da equipa
                public int D;//Aqui declara-se as derrotas da equipa
                public int GM;//Aqui declara-se os golos marcados da equipa
                public int GS;//Aqui declara-se os golos sofridos da equipa
            }

            //<-----------------------------FIM DA ESTRUTURA CLASSIFICAÇÃO---------------------------------------------->










            //<-------------------------------COMEÇO DA DECLARAÇÃO DOS VECTORES---------------------------------------------->




            public const int NEQUIPAS = 16; // Aqui declara-se que o numero total de equipas será de 16

            public static classificacao[] vectorEquipas = new classificacao[NEQUIPAS]; // Aqui declara o vector classificação

            public static classificacao[] vectorclassificacao = new classificacao[NJORNADAS]; // Aqui declara o vector classificação

            public const int NJORNADAS = 8; // Aqui declara-se que o numero de jornadas será 8
            public static int op = 0; // Variavel para a escolha no menu


            //<------------------------------FIM DA DECLARAÇÃO DOS VECTORES-------------------------------------------------->













            //<------------------------------COMEÇO DO SUBPROGRAMA PARA ACTUALIZAR A JORNADA---------------------------------------------->			





            public static void actualizajornada() // Aqui declara-se o nome e o tipo do subprograma
            {

                StreamReader fr = new StreamReader("jornada1.txt"); //escolher o ficheiro que vai ler

                string linha; // declara a variavel linha

                string[] campos = new string[4]; // Os campos a separar irão ser 4

                char[] separador = { ':' }; // O separador entre os campos ira ser ":"




                for (int i = 0; i < NJORNADAS; i++) //ciclo for para ler "NJORNADAS" linhas
                {


                    linha = fr.ReadLine(); // ler linha

                    Console.WriteLine(linha); // escrever no ecrã todas as linhas que ler

                    campos = linha.Split(separador); //Separa os campos pelo separador neste caso ":"

                    string n = Convert.ToString(Console.ReadLine()); //Declara a varivel n 





                    for (int k = 0; k < NEQUIPAS; k++) //ciclo for para ler o numero "NEQUIPAS"
                    {
                        if (vectorEquipas[i].NomeEquipa == n) // Se o nome da equipa for igual a n então
                        {
                            vectorEquipas[i].NomeEquipa = campos[0]; //Lê o nome da equipa (campo 0 )
                            vectorEquipas[i].GM = Convert.ToInt32(campos[1]); //Lê os golos marcados da equipa (campo 1 )
                            vectorEquipas[i].NomeEquipa = campos[2]; //Lê o nome da segunda equipa (campo 2 )
                            vectorEquipas[i].GS = Convert.ToInt32(campos[3]); //Lê os golos sofridos da equipa (campo 3 )

                            break; // comando para parar
                        }
                    }






                    if (vectorEquipas[i].GM > vectorEquipas[i].GS) // se os golos marcados forem mais que os golos sofridos então
                    {
                        vectorEquipas[i].Pts++;  //Adiciona mais um ponto
                        vectorEquipas[i].J++;    //Adiciona mais um jogo
                        vectorEquipas[i].V++;    //Adiciona mais uma vitoria
                        vectorEquipas[i].GM++;   //Adiciona mais X golos marcados
                        vectorEquipas[i].GS++;   //Adiciona mais X golos sofridos
                    }

                    if (vectorEquipas[i].GS > vectorEquipas[i].GM) // se os golos sofridos forem mais que os golos marcados então
                    {
                        vectorEquipas[i].GS++;   //Adiciona mais X golos sofridos
                        vectorEquipas[i].GM++;   //Adiciona mais X golos marcados
                        vectorEquipas[i].J++;    //Adiciona mais um jogo
                        vectorEquipas[i].D++; //Adiciona mais uma derrota

                    }

                    if (vectorEquipas[i].GS == vectorEquipas[i].GM) // se os golos sofridos forem iguais aos golos marcados então
                    {
                        vectorEquipas[i].Pts++; //Adiciona mais um ponto
                        vectorEquipas[i].J++;    //Adiciona mais um jogo
                        vectorEquipas[i].GM++;   //Adiciona mais X golos marcados
                        vectorEquipas[i].GS++;   //Adiciona mais X golos sofridos
                        vectorEquipas[i].E++;    //Adiciona mais um empate
                    }



                }
            }


            //<------------------------------FIM DO SUBPROGRAMA PARA ACTUALIZAR A JORNADA---------------------------------------------->








            //<------------------------------COMECO DO SUBPROGRAMA PARA LER A PARTIR DO FICHEIRO---------------------------------------------->


            public static void LerTXT() // Aqui declara-se o nome e o tipo do subprograma
            {
                StreamReader fr = new StreamReader("classificacao2.txt");
                string linha;

                string[] campos = new string[9];

                char[] separador = { ':' };

                for (int i = 0; i < NEQUIPAS; i++)
                {
                    linha = fr.ReadLine();
                    Console.WriteLine(linha);
                    campos = linha.Split(separador);
                    vectorEquipas[i].Posicao = Convert.ToInt32(campos[0]);
                    vectorEquipas[i].NomeEquipa = campos[1];
                    vectorEquipas[i].Pts = Convert.ToInt32(campos[2]);
                    vectorEquipas[i].J = Convert.ToInt32(campos[3]);
                    vectorEquipas[i].V = Convert.ToInt32(campos[4]);
                    vectorEquipas[i].E = Convert.ToInt32(campos[5]);
                    vectorEquipas[i].D = Convert.ToInt32(campos[6]);
                    vectorEquipas[i].GM = Convert.ToInt32(campos[7]);
                    vectorEquipas[i].GS = Convert.ToInt32(campos[8]);
                }
                fr.Close();

            }

            public static void ListaDados()
            {
                Console.WriteLine("Bwin  - Classificacao Geral");
                Console.WriteLine("");
                Console.WriteLine("\t\t\t    Pts\t    J\t  V\t  E\t D     GM     GS");
                foreach (classificacao e in vectorEquipas)
                {

                    Console.WriteLine("{0}\t{1,11}{2,11}{3,7}{4,7}{5,7}{6,7}{7,7}{8,7}", e.Posicao, e.NomeEquipa, e.Pts, e.J, e.V, e.E, e.D, e.GM, e.GS);



                }
            }


            public static void Ordenar()
            {
                int i = 0, j = 0;

                classificacao x = new classificacao();

                for (i = 1; i < NEQUIPAS; i++)
                {
                    x = vectorEquipas[i];
                    j = i;
                    while (vectorEquipas[j - 1].Pts < x.Pts && j >= 0)
                    {
                        vectorEquipas[j] = vectorEquipas[j - 1];
                        j--;
                        if (j == 0)
                        {
                            break;
                        }
                    }
                    vectorEquipas[j] = x;

                }
            }

            public static void Main(string[] args)
            {

                do
                {

                    Console.WriteLine("");
                    Console.WriteLine("     <.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.>");
                    Console.WriteLine("     <.>                                                                  <.>");
                    Console.WriteLine("     <.>     PRIMA:                                                       <.>");
                    Console.WriteLine("     <.>                  1    para Ler txt e passar para vector          <.>");
                    Console.WriteLine("     <.>                  2    para listar o que está no vector           <.>");
                    Console.WriteLine("     <.>                  3    para Ordenar tabela por Pontos             <.>");
                    Console.WriteLine("     <.>                  4    actualizar jornada                         <.>");
                    Console.WriteLine("     <.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.><.>");
                    Console.WriteLine("");
                    Console.Write("Introduza uma opção: ");
                    op = int.Parse(Console.ReadLine());
                    Console.WriteLine();
                    switch (op)
                    {

                        case 1:
                            LerTXT();
                            break;

                        case 2:
                            ListaDados();
                            Console.ReadLine();
                            break;

                        case 3:
                            Ordenar();
                            break;

                        case 4:
                            actualizajornada();
                            break;


                    }


                } while (op != 5);
            }
        }
    }
}
