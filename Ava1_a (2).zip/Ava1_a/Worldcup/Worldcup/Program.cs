﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Worldcup
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Grupo A");
            Console.WriteLine("Qatar vs Senegal");

            Random rnd = new Random();

            int gqatar = rnd.Next(0, 3);
      
            Random rnd2 = new Random();

            int gsenegal = rnd2.Next(0, 6);

            
            Console.WriteLine("Qatar: " + gqatar + " - " + gsenegal + " :Senegal");
            if (gqatar > gsenegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Qatar venceu!\n");
            }
            else if (gqatar == gsenegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("Empate!\n");

            }
            else if (gqatar < gsenegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Senegal venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;
            /*---------------------------------------------------------*/
            Console.WriteLine("\nProximo jogo: Equador vs Holanda");
            Console.WriteLine("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nClick ENTER for the next game");
            Console.ReadLine();
            Console.WriteLine("Equador vs Holanda");

            Random rnd3 = new Random();

            int gequador = rnd3.Next(0, 3);

            Random rnd4 = new Random();

            int gholanda = rnd4.Next(0, 6);


            Console.WriteLine("Equador: " + gequador + " - " + gholanda + " :Holanda");
            if (gequador > gholanda)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Equador venceu!\n");
            }
            else if (gequador == gholanda)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("Empate!\n");

            }
            else if (gequador < gholanda)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Holanda venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;
            /*---------------------------------------------------------*/
            Console.WriteLine("\nProximo jogo: Qatar vs Holanda");
            Console.WriteLine("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nClick ENTER for the next game");
            Console.ReadLine();
            Console.WriteLine("Qatar vs Senegal");

            Random rnd5 = new Random();

            int ggqatar = rnd5.Next(0,2);

            Random rnd6 = new Random();

            int ggholanda = rnd6.Next(0, 5);


            Console.WriteLine("Qatar: " + ggqatar + " - " + ggholanda + " :Holanda");
            if (ggqatar > ggholanda)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Qatar venceu!\n");
            }
            else if (ggqatar == ggholanda)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("Empate!\n");

            }
            else if (ggqatar < ggholanda)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Holanda venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;
            /*---------------------------------------------------------*/
            Console.WriteLine("\nProximo jogo: Equador vs Senegal");
            Console.WriteLine("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nClick ENTER for the next game");
            Console.ReadLine();
            Console.WriteLine("Equador vs Senegal");

            Random rnd7 = new Random();

            int ggequador = rnd7.Next(0, 4);

            Random rnd8 = new Random();

            int ggsenegal = rnd8.Next(0, 3);


            Console.WriteLine("Equador: " + ggequador + " - " + ggsenegal + " :Senegal");
            if (ggequador > ggsenegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Equador venceu!\n");
            }
            else if (ggequador == ggsenegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("Empate!\n");

            }
            else if (ggequador < ggsenegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Senegal venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;
            /*---------------------------------------------------------*/
            Console.WriteLine("\nProximo jogo: Holanda vs Senegal");
            Console.WriteLine("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nClick ENTER for the next game");
            Console.ReadLine();
            Console.WriteLine("Holanda vs Senegal");

            Random rnd9 = new Random();

            int gggholanda = rnd9.Next(0, 4);

            Random rnd10 = new Random();

            int gggsenegal = rnd10.Next(0, 2);


            Console.WriteLine("Holanda: " + gggholanda + " - " + gggsenegal + " :Senegal");
            if (gggholanda > gggsenegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Holanda venceu!\n");
            }
            else if (gggholanda == gggsenegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("Empate!\n");

            }
            else if (gggholanda < gggsenegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Senegal venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;
            /*---------------------------------------------------------*/
            Console.WriteLine("\nProximo jogo: Qatar vs Equador");
            Console.WriteLine("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nClick ENTER for the next game");
            Console.ReadLine();
            Console.WriteLine("Qatar vs Equador");

            Random rnd11 = new Random();

            int gggqatar = rnd11.Next(0, 2);

            Random rnd12 = new Random();

            int gggequador = rnd12.Next(0, 4);


            Console.WriteLine("Qatar: " + gggqatar + " - " + gggequador + " :Equador");
            if (gggqatar > gggequador)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Qatar venceu!\n");
            }
            else if (gggqatar == gggequador)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("Empate!\n");

            }
            else if (gggqatar < gggequador)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Equador venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;
            /*---------------------------------------------------------*/
            Console.WriteLine("\nProximo Grupo: B");
            Console.WriteLine("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nClick ENTER for the next game");
            Console.ReadLine();




        }
    }
}
