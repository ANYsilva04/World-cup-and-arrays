﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Iremos calcular dois números \n1 número:");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("2 número:");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("A soma do dois número é de "+(a + b));
            Console.ReadLine();

            Console.WriteLine("Insira um numero de 1 a 5:");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(VerDia(n1)); 
            Console.ReadLine();
        }
            
        static string VerDia(int DiaNum)
        {
            string DiaNome;
            switch (DiaNum)
            {
                case 0:
                    DiaNome = "Domingo";
                    break;
                case 1:
                    DiaNome = "Segunda";
                    break;
                case 2:
                    DiaNome = "Terça";
                    break;
                case 3:
                    DiaNome = "Quarta";
                    break;
                case 4:
                    DiaNome = "Quinta";
                    break;
                case 5:
                    DiaNome = "Sexta";
                    break;
                default:
                    DiaNome = "Numero invalido";
                    break;
            }
            return DiaNome;

        }
    }
}
