﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace metodo_potencia
{
    internal class Class1

    {
        static void Main(string[] args)
        {

            string[] arr = { "Even ", "Odd" };

            Console.Write("Enter the number: ");
            int no = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(arr[no % 2]);
            Console.ReadLine();

        }
    }
}
w