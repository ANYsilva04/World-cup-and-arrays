﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace metodo_potencia
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira um número:");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Agora um expoente para o seu número");
            int b = Convert.ToInt32(Console.ReadLine());

           

            Console.ReadLine();
        }
        static int potencia (int a , int b)
        {

            int i;
            int final = 1;

            for (int i = 0; i < b;  i++)
            {
                final = final * a;
            }
            return final; 
        }
    }
}
