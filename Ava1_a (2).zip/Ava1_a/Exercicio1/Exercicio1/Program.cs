﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Neste exercicio vamos ver se um número é impar ou par");
            Console.WriteLine(" a = 32");
            int a = 32;
            int final = (a % 2);
            Console.WriteLine("O numero a é par, pois o resto é de " + final);
            Console.WriteLine(" b = 35");
            int b = 35;
            int final2 = (b % 2);
            Console.WriteLine("O numero b é impar, pois o resto é de " + final2);




            Console.ReadLine();
        }
    }
}
